import formData from "form-data";
import Mailgun from "mailgun.js";

export const lambdaHandler = async (event, context) => {

    let nTotal = event.nTotal;
    let emailColab = event.emailColab;
    let dataToSend = event.dataToSend;
    let isOnlyOne = event.isOnlyOne;
    let bGoToNotificationsModule = event.bGoToNotificationsModule;

    if(nTotal) {

        
    let sUrl_Notifications_Module = event.sUrl_Notifications_Module


        const APIKEY = process.env.APIKEY; 
        const DOMAIN = process.env.DOMAIN;
        const MAILGUN_HOST = process.env.MAILGUN_HOST;

        const mailgun = new Mailgun(formData);
        const client = mailgun.client({ username: "api", key: APIKEY, url: MAILGUN_HOST });

        const messageData = {
            from: "Sistema Smart <smart@materiagris.pe>",
            to: emailColab,
            subject: "Tienes notificaciones pendientes 🧐.",
            template: 
                "massive_notification_test",
                "h:X-Mailgun-Variables": JSON.stringify({
                    nTotal: nTotal,
                    lModulos: dataToSend,
                    isOnlyOne: isOnlyOne,
                    bGoToNotificationsModule: bGoToNotificationsModule,
                    sUrl_Notifications_Module: sUrl_Notifications_Module
                })
        };

        try {
            const resp = await client.messages.create(DOMAIN, messageData);
            return {
                statusCode: 200,
                body: JSON.stringify({
                    message: `El mensaje se envió a ${emailColab}`,
                    cliente: resp.id
                }),
            };
        } catch (err) {
            return {
                statusCode: 500,
                body: JSON.stringify({
                    message: "Algo falló al enviar el correo",
                    error: err
                }),
            };
        }
    }
    else {
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "No hay notificaciones",
            }),
        };
    }
}