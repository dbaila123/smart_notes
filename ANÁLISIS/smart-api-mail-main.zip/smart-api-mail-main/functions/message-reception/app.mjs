export const lambdaHandler = async (event, context) => {

    let dataToFormat = event.sDataNotificacion;
    let emailColab = event.sCorreo;
    let nIdUsuario = event.nId_Usuario;
    let nTotal = dataToFormat[0].nTotal_Notifications;

    return { dataToFormat, emailColab, nIdUsuario, nTotal };
}