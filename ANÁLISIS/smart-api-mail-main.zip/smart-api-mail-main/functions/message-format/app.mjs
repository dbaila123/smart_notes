import moment from "moment";
import "moment/locale/es.js";
import { from, of, zip } from "rxjs";
import { groupBy, mergeMap, toArray } from "rxjs/operators";
import CryptoJS from "crypto-js";

const password = process.env.PASSWORD;

let nIdUsuario = 0;

export const lambdaHandler = async (event, context) => {

  let dataToSend;
  let isOnlyOne = false;
  let dataToFormat = event.dataToFormat;
  let emailColab = event.emailColab;
  let nTotal = dataToFormat[0].nTotal_Notifications;
  nIdUsuario = event.nIdUsuario;
  let bGoToNotificationsModule = nTotal > 5

  if(nTotal == 1){
    isOnlyOne = true
  }  

  dataToSend = groupByModules(dataToFormat);

  let sUrl_Notifications_Module = bGoToNotificationsModule ? getSmartNotificationsUrl(
    dataToFormat.filter(x => x.sLink_Notificacion != null)[0]
    .sLink_Notificacion) : false
  
  return {dataToSend, isOnlyOne, nTotal, emailColab, bGoToNotificationsModule, sUrl_Notifications_Module}

};


const getSmartNotificationsUrl = (url) =>{
  let parts = url.split('.')
  return `${parts[0]}.${parts[1]}.pe/notificaciones/lista`
}



// Data format

function groupByModules(data) {
    let notificationsDataTemp = [];
    from(data)
      .pipe(
        groupBy((notification) => notification.sModulo),
        mergeMap((group) => zip(of(group.key), group.pipe(toArray())))
      )
      .subscribe((finalGroup) => {
        let nameModule =finalGroup[0]
        notificationsDataTemp.push({
          sModulo: nameModule,
          lNotificaciones: setArrayOfNotifications(finalGroup[1]),
        });
      });
    return notificationsDataTemp;
   }
   
   function setArrayOfNotifications(aNotifications) {
    aNotifications.map((notification) => {
      notification.bUseButton = notification.sLink_Notificacion != null
      notification.humanizatedTime = setFirstLetterUppercase(getTimeHumanized(notification.dFecha_Creacion));
      notification.sMensaje = setDescriptionForNotification(notification.sMensaje, notification.sModulo);
      notification.sLink_Notificacion =  encriptUrl(notification.sLink_Notificacion+`&nIdNotificacion=${notification.nId_Notificacion}`);
    });
    return aNotifications;
   }
   
   function setDescriptionForNotification(mensaje, type){
    let oMsj = JSON.parse(mensaje);
    oMsj.existOwnerAndIsLoggedIn = oMsj.nPropietario != undefined && oMsj.nPropietario == nIdUsuario;
    oMsj.existOwnerAndIsNotLoggedIn = oMsj.nPropietario != undefined && oMsj.nPropietario != nIdUsuario;
   
    switch (type.toUpperCase()) {
      case "SOLICITUD":
        return setDescriptionForNotificationByRequest(oMsj);
   
      case "TAREO":
        return setDescriptionForNotificationByTareo(oMsj);
   
      case "ASISTENCIA":
        return setDescriptionForNotificationByAssistance(oMsj);
      
      case "REQUERIMIENTO":
        return setDescriptionForNotificationByRequirement(oMsj);
   
      case "TESORERÍA":
        return setDescriptionForNotificationByTreasuryRequest(oMsj);
      
      case 'PROYECTO':
        return setDescriptionForNotificationByProject(oMsj);
    }
   }
   
   function setDescriptionForNotificationByTareo(oMsj) {
     let sMsj = "<strong>" + setToTitleCase(oMsj.sInvolucrado) + "</strong> ";
     let hora = ''
     let dia = ''
     let mes = ''
     switch (oMsj.sAccion.toUpperCase()) {
       case "EDITAR":
           sMsj = sMsj + "ha resuelto " + ((oMsj.existOwnerAndIsLoggedIn) ? "tu" : "la") + " actividad observada";
         sMsj = sMsj + (oMsj.existOwnerAndIsNotLoggedIn ? ' de <strong> ' + setToTitleCase(oMsj.sPropietario) + "</strong>. " : '. ');
         oMsj.aTareo.forEach((change, index) => {
           sMsj =
             sMsj +
             "<strong>" +
             setFirstLetterUppercase(change.sCampo) +
             "</strong> cambió de <strong> " +
             setFirstLetterUppercase(change.sData_Old) +
             "</strong> a <strong> " +
             setFirstLetterUppercase(change.sData_New) +
             "</strong>";
           if (index < oMsj.aTareo.length - 1) {
             sMsj = sMsj + ", ";
           }
         });
         return sMsj + ".";
   
       case "OBSERVAR":
           sMsj = sMsj + " ha observado  " + ((oMsj.existOwnerAndIsLoggedIn) ? "tu" : "la") + " actividad";
           sMsj = sMsj + (oMsj.existOwnerAndIsNotLoggedIn ? ' de <strong> ' + setToTitleCase(oMsj.sPropietario) + "</strong>: " : ': ');
           sMsj = sMsj + '<strong class="bg-mg-base-background">' + oMsj.sObservacion + '"</strong>.'
           return sMsj;
        case 'LLENADO_TAREO':
            hora = oMsj.nHoursCount == 1 ? '1 hora' : `${oMsj.nHoursCount.toFixed(2)} horas`
            dia = oMsj.nDayCount == 1 ? '1 día' : `${oMsj.nDayCount} dias`
            sMsj = sMsj +`, no has registrado <strong>${hora}</strong> de actividades en <strong> ${dia}, </strong> por favor asegurate de hacerlo antes de que finalice el día.` 
            return sMsj;
        case 'LLENADO_TAREO_DIARIO':
            hora = oMsj.nHoursCount == 1 ? '1 hora' : `${oMsj.nHoursCount.toFixed(2)} horas`
            dia = oMsj.nDayCount == 1 ? '1 día' : `${oMsj.nDayCount} dias`
            mes = moment().format('MMMM')
            sMsj = sMsj +`, no has registrado <strong>${hora}</strong> de actividades en <strong> ${dia}, </strong> en el mes de <strong>${mes}</strong>. Por favor recuerda mantener actualizado tu tareo.` 
            return sMsj;
     }
   }
   
   function setDescriptionForNotificationByRequest(oMsj) {
     let conectorOwner = "";
     let sMsj = "<strong>" + setToTitleCase(oMsj.sInvolucrado) + "</strong> ";
   
     switch (oMsj.sAccion.toUpperCase()) {
       case "APROBAR":
         sMsj = sMsj + "ha aprobado " + (oMsj.existOwnerAndIsLoggedIn ? "tu" : "la") + " solicitud de ";
         conectorOwner = "de";
         break;
   
         case 'ANULAR':
          //sMsj = sMsj + 'ha anulado su solicitud de ';
          sMsj =
            sMsj +
            'ha anulado ' +
            (oMsj.existOwnerAndIsLoggedIn ? 'tu' : 'la') +
            ' solicitud de ';
          conectorOwner = 'de';
          break;
   
       case "RECHAZAR":
         sMsj = sMsj + "ha rechazado " + (oMsj.existOwnerAndIsLoggedIn ? "tu" : "la") + " solicitud de ";
         conectorOwner = "de";
         break;
   
       case "CREAR":
         sMsj = sMsj + (oMsj.existOwnerAndIsLoggedIn ? "te" : "") + " ha creado una solicitud de ";
         conectorOwner = "para";
         break;
     }
   
     sMsj =
       sMsj +
       "<strong> " +
       oMsj.oSolicitud.sTipo_Solicitud.toLowerCase() +
       "</strong> ";
     if (oMsj.existOwnerAndIsNotLoggedIn)
       sMsj =
         sMsj +
         " " +
         conectorOwner +
         " <strong> " +
         setToTitleCase(oMsj.sPropietario) +
         "</strong>, ";
   
     return (sMsj + setDescriptionForNotificationByRequestFrecuency(oMsj));
   }
   
   function setDescriptionForNotificationByRequestFrecuency(oMsj) {
     let dStart = moment(oMsj.oSolicitud.dFecha_Inicio, 'YYYY-MM-DDTHH:mm:ss');
     let dEnd = moment(oMsj.oSolicitud.dFecha_Fin, 'YYYY-MM-DDTHH:mm:ss');
     switch (oMsj.oSolicitud.nFrecuencia_Solicitud) {
       case 1:
         if (dStart.isSame(dEnd, "day")) {
           return (
             "para el <strong> " +
             formatDateMMofDDofYYYY(dStart) +
             "</strong> desde las <strong> " +
             dStart.format("HH:mm") +
             " Hrs</strong> hasta las <strong> " +
             dEnd.format("HH:mm") +
             " Hrs</strong>."
           );
         } else {
           return (
             "para el <strong> " +
             formatDateMMofDDofYYYY(dStart) +
             "</strong> - <strong> " +
             dStart.format("HH:mm") +
             " Hrs</strong> hasta <strong> " +
             formatDateMMofDDofYYYY(dEnd) +
             "</strong> - <strong> " +
             dEnd.format("HH:mm") +
             "Hrs</strong>. "
           );
         }
   
       case 2:
       case 3:
         if (dStart.isSame(dEnd, "day")) {
           return (
             "para el <strong> " + formatDateMMofDDofYYYY(dStart) + "</strong>."
           );
         } else {
           return (
             "para el <strong> " +
             formatDateMMofDDofYYYY(dStart) +
             "</strong> hasta el <strong>" +
             formatDateMMofDDofYYYY(dEnd) +
             "</strong>."
           );
         }
   
       default:
         return (
           "para el <strong> " + formatDateMMofDDofYYYY(dStart) + "</strong>."
         );
     }
   }
   
// -- REQUERIMENT
function setDescriptionForNotificationByRequirement(oMsj) {
    let sMsj = '<strong>' + setToTitleCase(oMsj.sInvolucrado) + '</strong>';
    switch (oMsj.sAccion.toUpperCase()) {
      case 'CREAR':
        return (
          sMsj +
          ' ha creado el requerimiento <strong> ' +
          oMsj.oRequerimiento.sNombre_Requerimiento +
          '</strong> para el proyecto <strong> ' +
          oMsj.oRequerimiento.sNombre_Proyecto +
          '</strong> y ha elegido como lider principal ha <strong> ' +
          oMsj.oRequerimiento.sNombre_Lider_principal_new +
          '</strong>'
        );
  
      case 'CREAR_LIDER_PRINCIPAL':
        return (
          sMsj +
          ' te ha asignado como lider principal para el requerimiento <strong> ' +
          oMsj.oRequerimiento.sNombre_Requerimiento +
          '</strong> del proyecto <strong> ' +
          oMsj.oRequerimiento.sNombre_Proyecto +
          '</strong>'
        );
  
      case 'EDITAR':
        sMsj =
          sMsj +
          ' ha editado el requerimiento <strong> ' +
          oMsj.oRequerimiento.sNombre_Requerimiento +
          '</strong> del proyecto <strong> ' +
          oMsj.oRequerimiento.sNombre_Proyecto +
          '</strong>. ';
        oMsj.oRequerimiento.aCambios.forEach((change, index) => {
          if (change.sNombre_Categoria != undefined) {
            if (change.sData_Old != undefined) {
              sMsj =
                sMsj +
                'Categoría <strong>' +
                setFirstLetterUppercase(change.sNombre_Categoria) +
                '</strong> cambió de <strong> ' +
                change.sData_Old +
                (change.sData_Old > 1 ? ' Hrs' : ' Hr') +
                '</strong> a <strong> ' +
                change.sData_New +
                (change.sData_New > 1 ? ' Hrs' : ' Hr') +
                '</strong>';
            } else {
              sMsj =
                sMsj +
                'Agregó la categoría <strong>' +
                setFirstLetterUppercase(change.sNombre_Categoria) +
                '</strong>';
            }
          } else {
            sMsj =
              sMsj +
              '<strong>' +
              setFirstLetterUppercase(change.sCampo) +
              '</strong> cambió de <strong> ' +
              setFirstLetterUppercase(change.sData_Old) +
              '</strong> a <strong> ' +
              setFirstLetterUppercase(change.sData_New) +
              '</strong>';
          }
          if (index < oMsj.oRequerimiento.aCambios.length - 1) {
            sMsj = sMsj + ', ';
          }
        });
        return sMsj + '.';
  
      case 'ACTUALIZAR_LP':
        return (
          sMsj +
          ' ha actualizado el lider principal en el requerimiento <strong> ' +
          oMsj.oRequerimiento.sNombre_Requerimiento +
          '</strong> del proyecto <strong> ' +
          oMsj.oRequerimiento.sNombre_Proyecto +
          '</strong>, cambiando a <strong> ' +
          oMsj.oRequerimiento.sNombre_Lider_principal_old +
          '</strong> por <strong> ' +
          oMsj.oRequerimiento.sNombre_Lider_principal_new +
          '</strong>'
        );
  
        case 'NOTIFICAR_LP_OLD':
          return (
            sMsj +
            ' te ha removido como lider principal en el requerimiento <strong> ' +
            oMsj.oRequerimiento.sNombre_Requerimiento +
            '</strong> del proyecto <strong> ' +
            oMsj.oRequerimiento.sNombre_Proyecto +
            '</strong>'
          );
  
        case 'NOTIFICAR_LP_NEW':
          return (
            sMsj +
            ' te ha asignado como lider principal en el requerimiento <strong> ' +
            oMsj.oRequerimiento.sNombre_Requerimiento +
            '</strong> del proyecto <strong> ' +
            oMsj.oRequerimiento.sNombre_Proyecto +
            '</strong>'
        );
  
      default:
        console.warn(
          'Error de acción en requerimiento notificación',
          oMsj.sAccion
        );
        return '';
    }
  }
   
   function setDescriptionForNotificationByAssistance(oMsj) {
     let sMsj = "<strong>" + setToTitleCase(oMsj.sInvolucrado) + "</strong> ";
     let dFechaMarca = null;
     switch (oMsj.sAccion.toUpperCase()) {
       case "CREAR":
           sMsj = sMsj + ((oMsj.existOwnerAndIsLoggedIn || oMsj.nPropietario == undefined) ? "te ha" : "ha") +
           " creado ";
         oMsj.aAsistencia.forEach((change, index) => {
           let dFecha = moment(change.dFecha_New);
           dFechaMarca = moment(change.dFecha_Marca);
           sMsj =
             sMsj +
             "la marca de <strong> " +
             change.sNombre_Marca.toLowerCase() +
             "</strong> para las <strong>" +
             dFecha.format("HH:mm") +
             " Hrs</strong>";
           if (index < oMsj.aAsistencia.length - 1) {
             sMsj = sMsj + ", ";
           }
         });
         break;
   
       case "EDITAR":
         sMsj = sMsj + "ha modificado ";
         oMsj.aAsistencia.forEach((change, index) => {
           dFechaMarca = moment(change.dFecha_Marca);
           let dFecha_New = moment(change.dFecha_New);
           let dFecha_Old = moment(change.dFecha_Old);
           sMsj =
             sMsj + ((oMsj.existOwnerAndIsLoggedIn || oMsj.nPropietario == undefined) ? "tu" : "la") +
             " marca de <strong> " +
             change.sNombre_Marca.toLowerCase() +
             "</strong> de las <strong> " +
             dFecha_Old.format("HH:mm") +
             " Hrs</strong> a las <strong>" +
             dFecha_New.format("HH:mm") +
             " Hrs</strong>";
           if (index < oMsj.aAsistencia.length - 1) {
             sMsj = sMsj + ", ";
           }
         });
         break;
   
       case 'ELIMINAR':
           sMsj = sMsj + "ha eliminado ";
           oMsj.aAsistencia.forEach((change, index) => {
               dFechaMarca = moment(change.dFecha_Marca);
               sMsj =
                 sMsj + ((oMsj.existOwnerAndIsLoggedIn || oMsj.nPropietario == undefined) ? "tu" : "la") +
                 " marca de <strong> " +
                 change.sNombre_Marca.toLowerCase() + '</strong>';
               if (index < oMsj.aAsistencia.length - 1) {
                 sMsj = sMsj + ", ";
               }
             });
         break;
               
        case 'INVALIDAR':
          let dFechaMarcaZ = moment(oMsj.oMarca.dFecha_Marca, 'YYYY-MM-DD HH:mm:ss');
          sMsj = 'Tu intento de marca </strong> para las <strong>';
          sMsj = sMsj + dFechaMarcaZ.format('HH:mm') + '</strong> del <strong>' + formatDateMMofDDofYYYY(dFechaMarcaZ) + '</strong> no pudo ser procesada. <br> Por favor, regulariza tu marca.'
          return sMsj;
          
     }
   
     if (oMsj.existOwnerAndIsNotLoggedIn) sMsj = sMsj + ' de <strong>' +  setToTitleCase(oMsj.sPropietario) + "</strong>";
     sMsj = sMsj + " del día <strong>" + dFechaMarca.format("DD") + " de " + dFechaMarca.format("MMMM");
     return sMsj;
   }
   
   // TESORERIA
   function setDescriptionForNotificationByTreasuryRequest(oMsj){
     oMsj.sCategoria_Solicitud_Tesoreria = "gastos";
     let conectorOwner = "";
     let sMsj = "<strong>" + setToTitleCase(oMsj.sInvolucrado) + "</strong> ";
   
     switch (oMsj.sAccion.toUpperCase()) {
       case "REEMBOLSAR":
         sMsj = sMsj + "ha efectuado el reembolso de tu solicitud de ";
         conectorOwner = "de";
         break;
   
       case "ANULAR":
         sMsj = sMsj + "ha anulado su solicitud de ";
         break;
   
       case "RECHAZAR":
         sMsj = sMsj + "ha rechazado tu solicitud de ";
         conectorOwner = "de";
         break;
   
       case "CREAR":
         sMsj = sMsj + " ha creado una solicitud de ";
         conectorOwner = "para";
         break;
     }
   
     sMsj =
       sMsj +
       "<strong> " +
       oMsj.sCategoria_Solicitud_Tesoreria +
       " por " +
       oMsj.oSolicitudTesoreria
       .sTipo_Solicitud_Tesoreria.toLowerCase() +
       "</strong> ";
     if (oMsj.existOwnerAndIsNotLoggedIn)
       sMsj =
         sMsj +
         " " +
         conectorOwner +
         " <strong> " +
         setToTitleCase(oMsj.sPropietario) +
         "</strong> ";
     sMsj = sMsj + 'del día <strong>' + formatDateMMofDDofYYYY(moment(oMsj.oSolicitudTesoreria.dFecha_Efecto)) +  "</strong>.";
   
     return (sMsj);
   }

   function setDescriptionForNotificationByProject(oMsj) {
    let sMsj = '<strong>' + setToTitleCase(oMsj.sInvolucrado) + '</strong> ';
    switch (oMsj.sAccion.toUpperCase()) {
      case 'ASIGNAR_D':
        return (
          sMsj +
          'ha asignado como líder a <strong> ' +
          oMsj.oProyecto.sNombre_Lideres +
          '</strong> para el proyecto <strong> ' +
          oMsj.oProyecto.sNombre_Proyecto +
          '</strong>.'
        );
  
      case 'RETIRAR_D':
        return (sMsj =
          sMsj +
          'ha removido como líder a <strong> ' +
          oMsj.oProyecto.sNombre_Lideres +
          '</strong> para el proyecto <strong> ' +
          oMsj.oProyecto.sNombre_Proyecto +
          '</strong>.');
  
      case 'ASIGNAR_L':
        return (
          sMsj +
          'te ha asignado como líder del proyecto <strong> ' +
          oMsj.oProyecto.sNombre_Proyecto +
          '</strong>.'
        );
  
      case 'RETIRAR_L':
        return (sMsj =
          sMsj +
          'te ha removido como líder del proyecto <strong> ' +
          oMsj.oProyecto.sNombre_Proyecto +
          '</strong>.');
  
      default:
        console.warn('Error de acción en proyecto notificación', oMsj.sAccion);
        return '';
    }
  }
   
   function encriptUrl(string){
  
    let baseUrl = string.split('?')
    let params = '?'
  
    if(baseUrl.length>1){
  
    
      baseUrl[1].split('&').forEach((elem)=>{
          let obj = {
            param: customEncrypt(password,elem.split('=')[0]),
            value: customEncrypt(password,elem.split('=')[1]) 
          }
          params = params+obj.param+'='+obj.value+'&'
      })
      return baseUrl[0]+params.slice(0,params.length-1);
    }else{
      return baseUrl[0]
    }
  }

  function customEncrypt(keys, value) {  
    var key = CryptoJS.enc.Utf8.parse(keys);
    var iv = CryptoJS.enc.Utf8.parse(keys);    
    var encrypted = CryptoJS.AES.encrypt(
      CryptoJS.enc.Utf8.parse(value.toString()),
      key,
      {
        keySize: 128 / 8,
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      }
    ); 
    return encodeURIComponent(encrypted.toString());
  }

// Utils

  function setFirstLetterUppercase(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }
  
  function getTimeHumanized(date){
    let dateMomentJs = moment(date);
    let dateHumanized = dateMomentJs.format("DD/MM/YYYY HH:mm");
    let difference = moment().diff(dateMomentJs, "days");
    if (difference <= 7) {
      dateHumanized = moment.duration(dateMomentJs.diff(moment())).humanize(true);
    } else {
      let month = [
        "",
        "enero",
        "febrero",
        "marzo",
        "abril",
        "mayo",
        "junio",
        "julio",
        "agosto",
        "septiembre",
        "octubre",
        "noviembre",
        "diciembre"
      ];
      let time = dateHumanized.split(" ");
      let date = time[0].split("/");
      dateHumanized = `${date[0]} ${month[Number(date[1])]} ${date[2]} - ${time[1]
        }`;
    }
   
    return dateHumanized;
   }
  
  function formatDateMMofDDofYYYY(date){
    return date.format('DD') + ' de ' + date.format('MMMM') + ' del ' + date.format('YYYY')
   }

  function setToTitleCase(str) {
    str = str.toLowerCase().split(" ");
    for (var i = 0; i < str.length; i++) {
      str[i] = str[i].charAt(0).toUpperCase() + str[i].slice(1);
    }
    return str.join(" ");
   }

